const { SlashCommandBuilder } = require('discord.js');
const file = './gesperrteUser.json'; // JSON-Datei zum Speichern der gesperrten Benutzer
const fs = require('fs');

let usersperre = [];
try {
  const data = fs.readFileSync(file, 'utf8'); // Hier Dateiname "file" verwenden
  usersperre = JSON.parse(data);
  if (!Array.isArray(usersperre)) {
    usersperre = []; // Initialize as an empty array if it's not already an array
  }
} catch (err) {
  console.error('Fehler beim Laden der gesperrtenUser.json-Datei:', err); // Hier Dateiname "gesperrteUser.json" verwenden
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('entsperren')
    .setDescription('Entperre einen User vom Modmail Systhem')
    .addUserOption(option => option
      .setName('user')
      .setDescription('Der user, der vom Modmail Systhem wiederaufgenommen werden soll')
      .setRequired(true)),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const { roles } = interaction.member;
    if (roles.cache.has('1092469722529927248')) {
      if (!Array.isArray(usersperre) || !usersperre.includes(user.id)) {
        interaction.reply('Der Benutzer ist nicht gebannt.');
      } else {
        usersperre = usersperre.filter((id) => id !== user.id);
        fs.writeFile(file, JSON.stringify(usersperre), (err) => { // Hier Dateiname "file" verwenden
          if (err) {
            console.error(err);
            interaction.reply('Beim Entfernen des Benutzers ist ein Fehler aufgetreten.');
          }
          interaction.reply(`Der Benutzer mit der ID ${user.id} wurde erfolgreich vom Modmail Systhem wieder hinzugefügt.`);
        });
      }
    } else {
      await interaction.reply({ content: 'Du bist nicht berechtigt den Command auszuführen!', ephemeral: true })
    }
  }
};
