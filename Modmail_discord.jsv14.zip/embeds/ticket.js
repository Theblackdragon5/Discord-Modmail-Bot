const { EmbedBuilder } = require('discord.js');

module.exports = {
    createEmbed: function () {
  const embed = new EmbedBuilder()
  .setColor('#0099ff')
  .setDescription('Wilkommen im Ticket')
  return embed
  }
};