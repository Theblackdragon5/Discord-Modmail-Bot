const { EmbedBuilder } = require('discord.js');

module.exports = {
    createEmbed: function () {
  const embed = new EmbedBuilder()
    .setTitle('Dies ist der Embed-Titel')
    .setColor('#0099ff')
    .setDescription('test')
    return embed
    }
};