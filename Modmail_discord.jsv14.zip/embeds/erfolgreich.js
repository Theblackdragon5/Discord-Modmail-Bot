const { EmbedBuilder } = require('discord.js');

module.exports = {
    createEmbed: function () {
  const embed = new EmbedBuilder()
    .setTitle('Ticket wurde erfolgreich erstellt')
    .setColor('#00ff00')
    .setDescription('bruh')
    return embed
    }
};