const { token, catId, pingrole, guildId } = require('./config.json')
const {
	Events,
	Client,
	GatewayIntentBits,
	PermissionFlagsBits,
	Partials,
	REST,
	Routes,
	ChannelType,
	ButtonBuilder,
	ButtonStyle,
    ActionRowBuilder,
	Collection,
	ComponentType,
	StringSelectMenuBuilder,
	StringSelectMenuOptionBuilder,
	EmbedBuilder
} = require('discord.js');

const fs = require('node:fs');
const path = require('node:path');

// Create a new client instance
const client = new Client({ intents: [
	GatewayIntentBits.Guilds,
	GatewayIntentBits.GuildMessages,
	GatewayIntentBits.MessageContent,
	GatewayIntentBits.DirectMessages,
	GatewayIntentBits.DirectMessageTyping,
	GatewayIntentBits.DirectMessageReactions
],
partials: [
	Partials.Message,
	Partials.Channel,
	Partials.GuildMember,
	Partials.GuildScheduledEvent,
	Partials.User,
],
});


let usersperre = [];
try {
	const data = fs.readFileSync('./gesperrteUser.json', 'utf8');
	usersperre = JSON.parse(data);
	if (!Array.isArray(usersperre)) {
		usersperre = []; // Initialize as an empty array if it's not already an array
	}
} catch (err) {
	console.error('Fehler beim Laden der ban.json-Datei:', err);
}


client.commands = new Collection();
const foldersPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(foldersPath);

for (const folder of commandFolders) {
	const commandsPath = path.join(foldersPath, folder);
	const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
	for (const file of commandFiles) {
		const filePath = path.join(commandsPath, file);
		const command = require(filePath);
		// Set a new item in the Collection with the key as the command name and the value as the exported module
		if ('data' in command && 'execute' in command) {
			client.commands.set(command.data.name, command);
		} else {
			console.log(`[WARNING] The command at ${filePath} is missing a required "data" or "execute" property.`);
		}
	}
}

client.login(token)
client.once('ready', async () => {
    // Inside the 'ready' callback
	console.log('[READY] Bot is up and ready to go.');

	// List of available statuses
	let statuses = [
		{ name: '.global-chat', type: 3 },
		{ name: 'bruh', type: 0 }
	];
	// Our pointer
	let i = 0;
	// Every 15 seconds, update the status
	setInterval(() => {
		// Get the status
		let status = statuses[i];
		// If it's undefined, it means we reached the end of the array
		if (!status) {
			// Restart at the first status
			status = statuses[0];
			i = 0;
		}
		client.user.setPresence(status);
		i++;
		console.log('Status updated:', status);
	}, 15000);

});



client.on(Events.InteractionCreate, async interaction => {
	if (!interaction.isChatInputCommand()) return;

	const command = interaction.client.commands.get(interaction.commandName);

	if (!command) {
		console.error(`No command matching ${interaction.commandName} was found.`);
		return;
	}

	try {
		await command.execute(interaction);
	} catch (error) {
		console.error(error);
		if (interaction.replied || interaction.deferred) {
			await interaction.followUp({ content: 'There was an error while executing this command!', ephemeral: true });
		} else {
			await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
		}
	}
});



const select = new ActionRowBuilder()
			.addComponents(
new StringSelectMenuBuilder()
	.setCustomId('starter')
	.setPlaceholder('Make a selection!')
	.addOptions(
		new StringSelectMenuOptionBuilder()
			.setLabel('Allgemein')
			.setDescription('Allgemeiner Support')
			.setValue('allgemein'),
		new StringSelectMenuOptionBuilder()
			.setLabel('Bewerbung')
			.setDescription('Teambewerbung')
			.setValue('bewerbung'),
		new StringSelectMenuOptionBuilder()
			.setLabel('Report')
			.setDescription('Reporte einen User')
			.setValue('report'),
	)
);

const öffnen = require('./embeds/dm').createEmbed()

client.on(Events.MessageCreate, async (message) => {
	
	const guild = client.guilds.cache.get(guildId);
	const user = message.author
	const userchannel = guild.channels.cache.find(channel => channel.name === user.username)
	if (message.channel.type === ChannelType.DM && !message.author.bot) {
		const messageEmbed = new EmbedBuilder()
			.setAuthor({ name: `${message.author.username}`, iconURL: `${message.author.avatarURL()}`, url: `https://discordapp.com/users/${message.author.id}/`})
			.setDescription(`${message.content}`)
			.setFooter({ text: 'Developed by theblackdragon5'});
		if (usersperre.includes(message.author.id)) {
			message.reply('Du wurdest vom Modmail Systhem ausgeschlossen!')
			return
		}
		else if (!userchannel) {
			console.log('dm')
			message.channel.send({embeds: [öffnen], components: [select]})
		}
		else if (userchannel && !usersperre.includes(message.author.id)) {
			userchannel.send({embeds: [messageEmbed]})
			message.react('✉️')
		}
	}
	else {
		if (message.author.bot) return;
		const messageEmbed = new EmbedBuilder()
			.setAuthor({ name: `${message.author.username}`, iconURL: `${message.author.avatarURL()}`, url: `https://discordapp.com/users/${message.author.id}/`})
			.setDescription(`${message.content}`)
			.setFooter({ text: 'Developed by theblackdragon5'});
		const userchname = message.channel.name;
		const user = guild.members.cache.find(member => member.user.username === userchname);
		if (user) {
		  user.send({embeds: [messageEmbed]})
		  message.react('✉️')
		}
	}
})

const ticket = require('./embeds/ticket').createEmbed()
client.on(Events.InteractionCreate, async (interaction) => {
	const guild = client.guilds.cache.get(guildId);
	const user = interaction.user.username
	const kathegorie = guild.channels.cache.find(CAT => CAT.id === catId)

	if (!pingrole) {
		console.error('Rolle nicht gefunden.');
		return;
	}
	if (!guild) {
		console.error('Server nicht gefunden.');
		return;
	}
	if (!kathegorie) {
		console.error('Kathegorie nicht gefunden.');
		return;
	}
	if (!interaction.isStringSelectMenu()) return;
	const selected = interaction.values[0];
	if (selected === 'allgemein') {
		ticket.setTitle('Allgemeines Ticket')
	}
	else if (selected === 'bewerbung') {
		ticket.setTitle('Bewerbung')
	}
	else if (selected === 'report') {
		ticket.setTitle('Report')
	}
	const ticketchannel = await guild.channels.create({
		name: user,
		type: ChannelType.GuildText,
		parent: kathegorie,
		permissionOverwrites: [
			{
				id: guild.roles.everyone.id,
				deny: [PermissionFlagsBits.ViewChannel],
			},
			{
				id: pingrole,
				allow: [PermissionFlagsBits.ViewChannel],
			},
		],
	});
	ticketchannel.send({embeds: [ticket]})
	const sucess = require('./embeds/erfolgreich').createEmbed()
	interaction.message.edit({ embeds: [sucess], components: []})
})


client.on(Events.InteractionCreate, async (interaction) => {
	if (interaction.isCommand()) {
	  const commandName = interaction.commandName;
  
		// if (commandName === 'entsperren') {
		// 	const data = fs.readFileSync('./gesperrteUser.json', 'utf8');
		// 	usersperre = JSON.parse(data);
		// }
	}
});

//Dieses Dokument darf nicht geändert werden, wie auch die Vermerkungen des Authors
//Weitere angaben zu der Lizens findet ihr in der package.json